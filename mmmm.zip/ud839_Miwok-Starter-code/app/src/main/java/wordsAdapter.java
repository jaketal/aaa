import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.miwok.R;
import com.example.android.miwok.Words;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class wordsAdapter extends ArrayList<Words> {


    public wordsAdapter(Activity context, ArrayList<Words> data) {
        super(context, 0, data);


    }

    public View getView(int position, View convertView, ViewGroup parent) {


        View listItemView = convertView;
        if(listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.test_layout, parent, false);}
            Words cureentword = get(position);
        TextView engtranslat = (TextView) listItemView.findViewById(R.id.eng_id);
        engtranslat.setText(cureentword.engTranslte);
        TextView aratranslat = (TextView) listItemView.findViewById(R.id.ara_id);
        aratranslat.setText(cureentword.araTranslate);
        return listItemView;
    }

}

