package com.example.android.miwok;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class NumbersActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numbers);

        ArrayList<com.example.android.miwok.Words> numbers = new ArrayList<com.example.android.miwok.Words>();
        numbers.add(new com.example.android.miwok.Words("one", "واحد"));
        numbers.add(new com.example.android.miwok.Words("two", "ثنين"));
        numbers.add(new com.example.android.miwok.Words("three", "ثلاثة"));
        numbers.add(new com.example.android.miwok.Words("four", "اربعة"));
        numbers.add(new com.example.android.miwok.Words("five", "خمسة"));
        numbers.add(new com.example.android.miwok.Words("six", "ستة"));
        numbers.add(new com.example.android.miwok.Words("seven", "سبعة"));
        numbers.add(new com.example.android.miwok.Words("eight", "ثمانية"));
        numbers.add(new com.example.android.miwok.Words("nine", "تسعة"));
        numbers.add(new com.example.android.miwok.Words("ten", "عشرة"));

        wordsAdapter adapter = new wordsAdapter(this,numbers);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);



    }


}








