package com.example.android.miwok;

public class Words {

    public  String engTranslte;
    public String  araTranslate;


    public Words(String engTranslte, String araTranslate) {
        engTranslte = engTranslte;
        araTranslate = araTranslate;
    }

    public String getEngTranslte(){
        return engTranslte;
    }
    public String getAraTranslate(){
        return araTranslate;
    }
}
